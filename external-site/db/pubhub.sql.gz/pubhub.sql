# ************************************************************
# Sequel Pro SQL dump
# Version 4529
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.5.5-10.1.14-MariaDB)
# Database: test
# Generation Time: 2016-06-06 20:21:25 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table pubs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pubs`;

CREATE TABLE `pubs` (
  `pub_id` int(11) DEFAULT NULL,
  `pub_name` varchar(255) DEFAULT NULL,
  `pub_address_1` varchar(255) DEFAULT NULL,
  `pub_address_2` varchar(255) DEFAULT NULL,
  `pub_town` varchar(255) DEFAULT NULL,
  `pub_city` varchar(255) DEFAULT NULL,
  `pub_postcode` varchar(255) DEFAULT NULL,
  `pub_type_of_night` varchar(255) DEFAULT NULL,
  `pub_budget` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `pubs` WRITE;
/*!40000 ALTER TABLE `pubs` DISABLE KEYS */;

INSERT INTO `pubs` (`pub_id`, `pub_name`, `pub_address_1`, `pub_address_2`, `pub_town`, `pub_city`, `pub_postcode`, `pub_type_of_night`, `pub_budget`)
VALUES
	(1,'The Hound','45, Fairfield Road','','Stratford','London','E15 2JD','watch-the-footy, after-work-drinks','low'),
	(2,'The Langthorne','14 Broadway',NULL,'Stratford','London','E15 4QS','datenight, quiet-night-with-mates','low'),
	(3,'Goose Stratford','78-102 Broadway',NULL,NULL,'London','E15 1NG','after-work-drinks, datenight','med'),
	(4,'Queens Head','5 W Ham Ln',NULL,NULL,'London','E15 4PH','watch-the-footy','low'),
	(5,'The White Horse','16 Newburgh St',NULL,'Soho','London','W1F 7RY','after-work-drinks, quiet-night-with-mates','med'),
	(6,'The George - Shepherd Neame',' D\'Arblay Street',NULL,'Soho','London','W1F 8DN','datenight, watch-the-footy, after-work-drinks','low'),
	(7,'The Green Man','57 Berwick St',NULL,'Soho','London','W1F 8SR','after-work-drinks, datenight','high'),
	(8,'The Henry Addington','22-28 Mackenzie Walk',NULL,NULL,'London','E14 4PH','after-work-drinks, quiet-night-with-mates, datenight','med'),
	(9,'The Tea Merchant','25-27 Fishermans Walk',NULL,NULL,'London','E14 4DH','watch-the-footy, datenight','high'),
	(10,'The Ledger Building','4 Hertsmere Rd',NULL,NULL,'London','E14 4AL','quiet-night-with-mates, after-work-drinks','low');

/*!40000 ALTER TABLE `pubs` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
